//
//  ViewController.swift
//  Rx_MVVM_TableView
//
//  Created by Hamlit Jason on 2021/07/12.
//

import UIKit
import RxSwift
import RxCocoa

class MainViewController: UIViewController {

    /* MVVM
     
     View : 구현
      - MainViewController
      - TableView 구성하는 부분을 따로 빼볼까?
     
     ViewModel : 값 대입
      - TableViewModel
     
     Model : 선언
      - TableCell
     
     */
    
    @IBOutlet weak var tableView: UITableView!
    var disposeBag = DisposeBag()
    
    @IBAction func APILoadButton(_ sender: Any) {
        LoadAPIFile.loadMembers()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] members in
                TableModel.shared.data = members
                self!.tableView.reloadData()
                print("\(TableModel.shared.data)")
            }).disposed(by: disposeBag)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}

extension MainViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TableModel.shared.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell") as! TableCell
        print("\(TableModel.shared.data[indexPath.row].name)")
        
        cell.setData(TableModel.shared.data[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }

}


extension MainViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = indexPath.row
        performSegue(withIdentifier: "DetailViewController", sender: row)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let id = segue.identifier,
            id == "DetailViewController",
            let detailVC = segue.destination as? DetailViewController,
            let row = sender else {
            return
        }
        
        detailVC.row = row as? Int
        
    }
    
}
