//
//  TableModel.swift
//  Rx_MVVM_TableView
//
//  Created by Hamlit Jason on 2021/07/12.
//

import UIKit
import RxSwift
import RxCocoa

class TableModel {
    
    static var shared = TableModel() // 싱글톤
    
    var data : [Member] = []
    //var data = BehaviorSubject<[Member]>(value: [])
    
    func UpdataUI() {
        
    }
    
    
    
}
