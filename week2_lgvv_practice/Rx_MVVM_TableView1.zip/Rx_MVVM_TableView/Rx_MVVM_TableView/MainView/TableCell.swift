//
//  TableCell.swift
//  Rx_MVVM_TableView
//
//  Created by Hamlit Jason on 2021/07/12.
//

import UIKit
import RxSwift

class TableCell : UITableViewCell {
    @IBOutlet var avatar: UIImageView!
    @IBOutlet var name: UILabel!
    @IBOutlet var job: UILabel!
    @IBOutlet var age: UILabel!
    
    var disposeBag = DisposeBag()
    
    //var row : Int!
    func setData(_ data: Member) {
        LoadAPIFile.loadImage(from: data.avatar)
            .observeOn(MainScheduler.instance)
            .bind(to: avatar.rx.image)
            .disposed(by: disposeBag)
        avatar.image = nil
        name.text = data.name
        job.text = data.job
        age.text = "(\(data.age))"
    }
}
