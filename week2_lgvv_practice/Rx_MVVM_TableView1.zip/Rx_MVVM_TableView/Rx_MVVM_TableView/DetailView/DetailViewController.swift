//
//  DetailViewController.swift
//  Rx_MVVM_TableView
//
//  Created by Hamlit Jason on 2021/07/13.
//

import UIKit
import RxSwift


class DetailViewController : UIViewController {
    
    @IBOutlet var avatar: UIImageView!
    @IBOutlet var id: UILabel!
    @IBOutlet var name: UILabel!
    @IBOutlet var job: UILabel!
    @IBOutlet var age: UILabel!
    
    
    var row: Int!
    var disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        
        self.id.text = "# \(TableModel.shared.data[row].id)"
        self.name.text = "# \(TableModel.shared.data[row].name)"
        self.job.text = "# \(TableModel.shared.data[row].job)"
        self.age.text = "\(TableModel.shared.data[row].age)"
        
        LoadAPIFile.loadImage(from: TableModel.shared.data[row].avatar)
            .observeOn(MainScheduler.instance)
            .bind(to: avatar.rx.image)
            .disposed(by: disposeBag)
        
    }
    
    private func makeBig(_ url: String) -> Observable<String> {
        return Observable.just(url)
            .map { $0.replacingOccurrences(of: "size=50x50&", with: "") }
    }
    
}
